package com.karrar.temp;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class ConverterUtilTest {
    public void testConvertFahrenheitToCelsius() {
        float actual = ConverterUtil.convertCelsiusToFahrenheit(100);
        // expected value is 212
        float expected = 212;

        assertEquals("Conversion from celsius to fahrenheit failed", expected, actual, 0.001);
    }

    @Test
    public void testConvertCelsiusToFahrenheit() {
        float actual = ConverterUtil.convertFahrenheitToCelsius(212);
        // expected value is 100
        float expected = 100;

        assertEquals("Conversion from celsius to fahrenheit failed", expected, actual, 0.001);
    }

}


