package com.karrar.temp;

import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withParent;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;



public class toFahrenheit_MainActivityTest {
    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void toFahrenheit_MainActivityTest() {
        ViewInteraction editText = onView(
                allOf(withId(R.id.inputValue), isDisplayed()));
        editText.perform(click());

        ViewInteraction editText2 = onView(
                allOf(withId(R.id.inputValue), isDisplayed()));
        editText2.perform(replaceText("212"), closeSoftKeyboard());

        ViewInteraction radioButton = onView(
                allOf(withId(R.id.radio1), withText("to Fahrenheit"),
                        withParent(withId(R.id.radioGroup1)),
                        isDisplayed()));
        radioButton.perform(click());

        ViewInteraction button = onView(
                allOf(withId(R.id.button1), withText("Calculate"), isDisplayed()));
        button.perform(click());

        ViewInteraction editText3 = onView(
                allOf(withId(R.id.inputValue), withText("413.6"), isDisplayed()));
        editText3.perform(click());

    }

}
